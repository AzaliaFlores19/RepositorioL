#include "node.h"

Node::Node(int value)
{
    this->next=nullptr;
    this->value=value;
}
